import axios from 'axios';

async function run() {
  const apiKey = 'AIzaSyA53yXiTvxJ5hSXNdieWEmLAUwXFxZfP5o';
  
  console.log('Testing gemini-1.5-flash via fetch (v1)...');
  try {
    const response = await axios.post(
      `https://generativelanguage.googleapis.com/v1/models/gemini-1.5-flash:generateContent?key=${apiKey}`,
      {
        contents: [{ parts: [{ text: 'Hello' }] }]
      }
    );
    console.log('v1 Success:', response.data.candidates[0].content.parts[0].text);
  } catch (e) {
    console.error('v1 Failed:', e.response?.data || e.message);
  }

  console.log('Testing gemini-1.5-flash via fetch (v1beta)...');
  try {
    const response = await axios.post(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`,
      {
        contents: [{ parts: [{ text: 'Hello' }] }]
      }
    );
    console.log('v1beta Success:', response.data.candidates[0].content.parts[0].text);
  } catch (e) {
    console.error('v1beta Failed:', e.response?.data || e.message);
  }
}

run();
