import axios from 'axios';

async function run() {
  const apiKey = 'AIzaSyA53yXiTvxJ5hSXNdieWEmLAUwXFxZfP5o';
  
  const models = [
    'gemini-1.5-flash-001',
    'gemini-1.5-flash-002',
    'gemini-1.5-flash-8b',
    'gemini-1.5-flash-latest'
  ];

  for (const model of models) {
    console.log(`Testing ${model}...`);
    try {
      const response = await axios.post(
        `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`,
        {
          contents: [{ parts: [{ text: 'Hello' }] }]
        }
      );
      console.log(`${model} Success!`);
    } catch (e) {
      console.log(`${model} Failed: ${e.response?.status}`);
    }
  }
}

run();
