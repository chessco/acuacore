import { NestFactory } from '@nestjs/core';
import { AppModule } from './src/app.module';
import { AiService } from './src/modules/ai/ai.service';

async function run() {
  const app = await NestFactory.createApplicationContext(AppModule);
  const aiService = app.get(AiService);
  const genAI = (aiService as any).genAI;
  
  try {
    const models = await genAI.listModels();
    console.log('Available Models:', models);
  } catch (e) {
    console.error('Error listing models:', e);
  }

  await app.close();
}

run();
