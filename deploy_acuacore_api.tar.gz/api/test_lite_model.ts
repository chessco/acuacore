import axios from 'axios';

async function run() {
  const apiKey = 'AIzaSyA53yXiTvxJ5hSXNdieWEmLAUwXFxZfP5o';
  
  console.log('Testing gemini-2.5-flash-lite...');
  try {
    const response = await axios.post(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-lite:generateContent?key=${apiKey}`,
      {
        contents: [{ parts: [{ text: 'Hello' }] }]
      }
    );
    console.log('Lite Success!');
  } catch (e) {
    console.error('Lite Failed:', e.response?.data?.error?.message || e.message);
  }
}

run();
