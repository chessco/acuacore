import { PrismaClient } from './node_modules/@prisma/mysql-client';

const prisma = new PrismaClient();

async function main() {
  const actions = await prisma.hitlAction.findMany({
    include: {
      message: true
    },
    orderBy: {
      createdAt: 'desc'
    }
  });

  console.log(JSON.stringify(actions, null, 2));
}

main()
  .catch(e => console.error(e))
  .finally(async () => await prisma.$disconnect());
