import { NestFactory } from '@nestjs/core';
import { AppModule } from './src/app.module';
import { DatabaseService } from './src/common/database/database.service';
import { KnowledgeBaseService } from './src/modules/knowledge-base/knowledge-base.service';

async function run() {
  const app = await NestFactory.createApplicationContext(AppModule);
  const db = app.get(DatabaseService);
  const kbService = app.get(KnowledgeBaseService);
  
  console.log('--- Database Repair Initialized ---');

  try {
    // 1. Enable pgvector
    console.log('Enabling pgvector extension...');
    await db.postgres.$executeRawUnsafe('CREATE EXTENSION IF NOT EXISTS vector');

    // 2. Create VectorRecord table
    console.log('Creating VectorRecord table...');
    await db.postgres.$executeRawUnsafe(`
      CREATE TABLE IF NOT EXISTS "VectorRecord" (
        "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        "tenantId" TEXT,
        "content" TEXT,
        "embedding" vector(768),
        "refId" TEXT,
        "refType" TEXT,
        "metadata" JSONB,
        "createdAt" TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // 3. Clear any existing data (just in case)
    await db.postgres.$executeRawUnsafe('TRUNCATE TABLE "VectorRecord"');

    // 4. Fetch all KB entries from MySQL
    console.log('Fetching KB entries from MySQL...');
    const entries = await db.mysql.knowledgeBase.findMany({
      include: { chunks: true }
    });

    console.log(`Found ${entries.length} entries. Syncing to Postgres...`);

    for (const entry of entries) {
      for (const chunk of entry.chunks) {
        console.log(`Syncing chunk for: ${entry.title}`);
        
        const aiService = app.get(require('./src/modules/ai/ai.service').AiService);
        const embedding = await aiService.getEmbedding(chunk.content);
        
        await db.postgres.$executeRawUnsafe(
          `INSERT INTO "VectorRecord" ("tenantId", "content", "embedding", "refId", "refType") 
           VALUES ('${entry.tenantId || 'edd1ac37-5ff9-4e46-bc7f-fff3c414d718'}', '${chunk.content.replace(/'/g, "''")}', '[${embedding.join(',')}]', '${entry.id}', 'KB')`
        );
      }
    }

    console.log('--- Sync Completed Successfully ---');
  } catch (e) {
    console.error('Repair failed:', e);
  }

  await app.close();
}

run();
