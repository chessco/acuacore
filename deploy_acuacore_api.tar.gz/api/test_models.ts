import { NestFactory } from '@nestjs/core';
import { AppModule } from './src/app.module';
import { AiService } from './src/modules/ai/ai.service';

async function run() {
  const app = await NestFactory.createApplicationContext(AppModule);
  const aiService = app.get(AiService);
  
  try {
    console.log('Testing gemini-1.5-flash...');
    const res = await aiService.generateRaw('Hello, say test', 'gemini-1.5-flash');
    console.log('Flash Result:', res);
  } catch (e) {
    console.error('Flash failed:', e.message);
  }

  try {
    console.log('Testing gemini-pro...');
    const res = await aiService.generateRaw('Hello, say test', 'gemini-pro');
    console.log('Pro Result:', res);
  } catch (e) {
    console.error('Pro failed:', e.message);
  }

  await app.close();
}

run();
