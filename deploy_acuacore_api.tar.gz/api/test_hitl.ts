import { NestFactory } from '@nestjs/core';
import { AppModule } from './src/app.module';
import { DatabaseService } from './src/common/database/database.service';

async function run() {
  const app = await NestFactory.createApplicationContext(AppModule);
  const db = app.get(DatabaseService);
  
  const cases = await db.mysql.hitlAction.findMany();
  console.log('HITL Actions in DB:', cases);
  await app.close();
}

run();
