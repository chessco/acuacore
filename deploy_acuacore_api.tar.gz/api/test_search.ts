import { NestFactory } from '@nestjs/core';
import { AppModule } from './src/app.module';
import { KnowledgeBaseService } from './src/modules/knowledge-base/knowledge-base.service';

async function run() {
  const app = await NestFactory.createApplicationContext(AppModule);
  const kb = app.get(KnowledgeBaseService);
  
  // Need to mock the Tenant storage context or bypass it
  // Actually getTenantId throws if not in context, wait!
  // Our updated getTenantId() returns a default if not found.
  
  const res = await kb.search('tilapia', 2);
  console.log(res);
  await app.close();
}

run();
