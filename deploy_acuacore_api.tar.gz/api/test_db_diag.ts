import { NestFactory } from '@nestjs/core';
import { AppModule } from './src/app.module';
import { DatabaseService } from './src/common/database/database.service';

async function run() {
  const app = await NestFactory.createApplicationContext(AppModule);
  const db = app.get(DatabaseService);
  
  // Check VectorRecord in Postgres
  try {
    const vectors = await db.postgres.$queryRawUnsafe('SELECT "tenantId", "content", "refId" FROM "VectorRecord" LIMIT 10');
    console.log('Vectors in Postgres:', vectors);
  } catch (e) {
    console.error('Error querying Postgres:', e);
  }

  // Check KnowledgeBase in MySQL
  try {
    const kb = await db.mysql.knowledgeBase.findMany();
    console.log('KB in MySQL:', kb);
  } catch (e) {
    console.error('Error querying MySQL:', e);
  }

  await app.close();
}

run();
