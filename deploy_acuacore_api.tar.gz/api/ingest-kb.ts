import { PrismaClient } from '@prisma/mysql-client';
import * as fs from 'fs';
import * as path from 'path';

const prisma = new PrismaClient();

async function ingestFile(filePath: string, title: string) {
    console.log(`📖 Ingesting: ${title}...`);
    const content = fs.readFileSync(filePath, 'utf-8');
    
    // 0. Delete existing KB with same title to avoid duplicates
    const existing = await prisma.knowledgeBase.findFirst({ where: { title } });
    if (existing) {
        await prisma.knowledgeBaseChunk.deleteMany({ where: { kbId: existing.id } });
        await prisma.knowledgeBase.delete({ where: { id: existing.id } });
    }

    // 1. Create KB entry
    const kb = await prisma.knowledgeBase.create({
        data: {
            title,
            version: '1.0',
        }
    });

    // 2. Simple Chunking (1000 chars with 100 overlap)
    const chunkSize = 1000;
    const overlap = 100;
    let start = 0;
    let sequence = 0;

    while (start < content.length) {
        const chunkContent = content.substring(start, start + chunkSize);
        await prisma.knowledgeBaseChunk.create({
            data: {
                kbId: kb.id,
                content: chunkContent,
                sequence: sequence++,
            }
        });
        start += chunkSize - overlap;
    }

    console.log(`✅ ${title} ingested in ${sequence} chunks.`);
}

async function main() {
    const knowledgeDir = path.join(__dirname, 'knowledge');
    if (!fs.existsSync(knowledgeDir)) {
        console.error(`❌ Knowledge directory not found: ${knowledgeDir}`);
        return;
    }

    const files = fs.readdirSync(knowledgeDir).filter(f => f.endsWith('.md'));
    
    for (const fileName of files) {
        const fullPath = path.join(knowledgeDir, fileName);
        // Create title from filename: vibrio.md -> Protocolo: Vibrio
        const baseName = fileName.replace('.md', '');
        const title = baseName.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
        
        await ingestFile(fullPath, title);
    }
}

main()
    .catch(e => console.error(e))
    .finally(async () => await prisma.$disconnect());
