import { NestFactory } from '@nestjs/core';
import { AppModule } from './src/app.module';
import { AiRouterService } from './src/modules/ai/ai-router.service';

async function test() {
    const app = await NestFactory.createApplicationContext(AppModule);
    const router = app.get(AiRouterService);
    
    const input = "Cómo puede ayudar a mis cultivos de camarón he visto una alta mortalidad";
    const skills = { don_juan_camaron: true };
    const tenantId = "cm7u1z8j500003b6q9q5q9q5q"; // Need a valid tenantId from DB
    
    console.log("Routing request...");
    try {
        const result = await router.route(input, undefined, skills);
        console.log("Decision:", result.decision);
        console.log("Content:", result.content);
    } catch (e) {
        console.error("Error:", e.message);
    }
    
    await app.close();
}

test();
