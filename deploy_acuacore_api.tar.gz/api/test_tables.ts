import { NestFactory } from '@nestjs/core';
import { AppModule } from './src/app.module';
import { DatabaseService } from './src/common/database/database.service';

async function run() {
  const app = await NestFactory.createApplicationContext(AppModule);
  const db = app.get(DatabaseService);
  
  try {
    const tables = await db.postgres.$queryRawUnsafe("SELECT table_name FROM information_schema.tables WHERE table_schema = 'public'");
    console.log('Tables in Postgres:', tables);
  } catch (e) {
    console.error('Error listing tables:', e);
  }

  await app.close();
}

run();
