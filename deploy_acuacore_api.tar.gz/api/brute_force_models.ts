import axios from 'axios';

async function run() {
  const apiKey = 'AIzaSyA53yXiTvxJ5hSXNdieWEmLAUwXFxZfP5o';
  
  const modelsToTest = [
    'gemini-1.0-pro',
    'gemini-pro',
    'gemini-1.5-flash',
    'gemini-1.5-pro',
    'text-bison-001',
    'chat-bison-001'
  ];

  for (const model of modelsToTest) {
    console.log(`Testing ${model}...`);
    try {
      const response = await axios.post(
        `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`,
        {
          contents: [{ parts: [{ text: 'Hello' }] }]
        }
      );
      console.log(`${model} Success!`);
    } catch (e) {
      console.log(`${model} Failed: ${e.response?.data?.error?.message || e.message}`);
    }
  }
}

run();
