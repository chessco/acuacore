import { ExtractJwt, Strategy } from 'passport-jwt';
import { PassportStrategy } from '@nestjs/passport';
import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy) {
    constructor(private configService: ConfigService) {
        super({
            jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
            ignoreExpiration: false,
            secretOrKey: configService.get<string>('JWT_SECRET') || 'pitaya_secret_prod_key',
        });
    }

    async validate(payload: any) {
        return {
            userId: payload.sub,
            id: payload.sub,
            email: payload.email,
            tenantId: payload.tenantId,
            role: payload.role
        };
    }
}
